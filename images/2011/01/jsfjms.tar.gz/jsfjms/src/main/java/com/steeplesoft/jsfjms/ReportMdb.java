package com.steeplesoft.jsfjms;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author jasonlee
 */
@MessageDriven(mappedName = "jms/Queue", 
        activationConfig = {
    @ActivationConfigProperty(propertyName = "acknowledgeMode",
        propertyValue = "Auto-acknowledge"),
    @ActivationConfigProperty(propertyName = "destinationType",
        propertyValue = "javax.jms.Queue")
})
public class ReportMdb implements MessageListener {
    @Resource(name = "mail/myserver")
    private Session mailSession;
    private static final Logger logger = Logger.getLogger(ReportMdb.class.getName());

    @Override
    public void onMessage(Message inMessage) {
        ObjectMessage msg = null;

        try {
            if (inMessage instanceof ObjectMessage) {
                msg = (ObjectMessage) inMessage;
                Object obj = msg.getObject();
                if (! (obj instanceof ReportRequest)) {
                    throw new RuntimeException("Invalid message payload.  ReportRequest required, but found " + obj.getClass().getName());
                }
                ReportRequest request = (ReportRequest)obj;
                logger.log(Level.INFO, "Sending report to {0}", request.emailAddress);
                sendMessage(request.emailAddress);
            } else {
                logger.log(Level.WARNING, "Message of wrong type: {0}", inMessage.getClass().getName());
            }
        } catch (JMSException e) {
            logger.log(Level.SEVERE, "Error:  {0}", e.getLocalizedMessage());
        }
    }

    protected void sendMessage(String emailAddress) {
        MimeMessage msg = new MimeMessage(mailSession);
        try {
            msg.setSubject("Your Report");
            msg.setRecipient(RecipientType.TO, new InternetAddress(emailAddress));
            msg.setText("Here is your report!");
            Transport.send(msg);
        } catch (MessagingException me) {
            logger.log(Level.SEVERE, "Error:  {0}", me.getLocalizedMessage());
        }
    }
}