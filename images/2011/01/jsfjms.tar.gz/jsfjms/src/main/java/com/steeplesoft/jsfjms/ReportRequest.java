package com.steeplesoft.jsfjms;

import java.io.Serializable;

/**
 *
 * @author jasonlee
 */
public class ReportRequest implements Serializable {
    public String emailAddress;

    public ReportRequest(String emailAddress) {
        this.emailAddress = emailAddress;
    }
}
