package com.steeplesoft.scala.glassfish.deploy

import com.sun.jersey.api.client.Client
import com.sun.jersey.api.client.ClientResponse
import com.sun.jersey.multipart.FormDataMultiPart
import com.sun.jersey.multipart.file.FileDataBodyPart
import javax.ws.rs.core.MediaType

import java.io.File
import scala.xml._

object Main {
  def main(args: Array[String]): Unit = {
    val deployer = new GlassFishDeployer
    deployer.deployApp("test.war");
    deployer.applications foreach println 
  }

}

object GlassFishDeployer {
  val RESPONSE_TYPE = "application/xml"
}

class GlassFishDeployer {
  val url = "http://localhost:4848/management/domain"
  val client: Client = Client.create()

  /**
   * Get the management URLs for each deployed app
   */
  def applications: List[String] = {
    var apps = List[String]()
    val xml = XML.loadString(client.resource(url + "/applications/application")
      .accept(GlassFishDeployer.RESPONSE_TYPE)
      .get(classOf[String]))

    for (entry <- ((xml \\ "entry" filter { node => (node \ "@key").text == "childResources" }) \ "map" \ "entry")) {
      apps ::= entry.attributes("value").text
    }
    return apps
  }

  def deployApp(pathToArchive: String) = {
    postWithUpload("/applications/application", Map[String, Any](
      "id" -> new File(pathToArchive),
      "contextroot" -> "testApp",
      "force" -> "true"))
  }

  def postWithUpload(address: String, payload: Map[String, Any]) = {
    val form = new FormDataMultiPart();
    for ((key, value) <- payload) {
      value match {
        case x: File => form.getBodyParts().add((new FileDataBodyPart(key, value.asInstanceOf[File])))
        case _ => form.field(key, value, MediaType.TEXT_PLAIN_TYPE)
      }
    }

    client.resource(url + address)
      .`type`(MediaType.MULTIPART_FORM_DATA)
      .accept(GlassFishDeployer.RESPONSE_TYPE)
      .post(classOf[ClientResponse], form)
  }
}