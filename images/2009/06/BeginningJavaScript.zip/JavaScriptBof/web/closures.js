function jediMindTrick(text) {
    var fullText = "*waves hands* " + text;
    text2 = "*waves hands* " + text;
    return function() {
        println (fullText);
    }
}

notTheDroids = jediMindTrick ("These are not the droids...");
println (jediMindTrick);
var foo = jediMindTrick;
println(foo);
notTheDroids();
println (notTheDroids.text2);
