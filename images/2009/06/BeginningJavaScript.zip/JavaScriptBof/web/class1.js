function MyClass() {
    this.foo = "bar";
    this.getFoo = function() {
        return this.foo;
    }
}

var instance = new MyClass();
println (instance.getFoo());
instance.foo = "Hi!"
println (instance.getFoo());