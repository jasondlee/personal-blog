function SuperClass() {
    this.className = "SuperClass";
    this.superOne = function() {
        println(this.className + ".superOne()");
    }
    this.superTwo = function() {
        println(this.className + ".superTwo()");
    }
}
function SubClass() {
    this.className = "SubClass";
    this.subOne = function() {
        println(this.className + ".subOne()");
    }
}

// This is the imporant line
SubClass.prototype = new SuperClass();

var superClass = new SuperClass();
var subClass = new SubClass();

superClass.superOne();
superClass.superTwo();

subClass.subOne();
subClass.superOne();
subClass.superTwo();