var array1 = [1,2,3,4,5];
var array2 = new Array(1,2,3,4,5);
var object1 = {foo1 : "bar", foo2 : "baz"};

println("array1 = " + array1);
println("array2 = " + array2);
println(object1);

for (prop in object1) {
    println ("object1['"+prop+"'] = " + object1[prop]);
}