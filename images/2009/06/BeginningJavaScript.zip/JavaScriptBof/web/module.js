if  (typeof alert == "undefined") {
    alert = println;
}


var childManager = (function(){
    var children = [];
    
    return {
      addChild: function(child) { children[child.name] = child; },
      removeChild: function(name) { /*children[name] = undefined;*/ },
      getChild: function(name) { return children[name]; }
    }
})();

childManager.addChild({name: "Timmy", hobby: "baseball"});
childManager.addChild({name: "Sallly", hobby: "barbie"});

println ("childManager.children = " + childManager.children);

var timmy1 = childManager.getChild("Timmy");
childManager.removeChild("Timmy");
var timmy2 = childManager.getChild("Timmy");

alert (timmy1);
alert (timmy2);