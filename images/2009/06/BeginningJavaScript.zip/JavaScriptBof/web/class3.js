var instance = new function() {
    this.foo = "bar";
    this.getFoo = function() {
        return this.foo;
    }
}

println (instance.getFoo());
instance.foo = "Hi!"
println (instance.getFoo());