var instance = {
    foo : "bar",
    getFoo : function() {
        return this.foo;
    }
}

println (instance.getFoo());
instance.foo = "Hi!"
println (instance.getFoo());