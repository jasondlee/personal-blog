var events = [];

function subscribe(event, callback) {
    events[event] = callback;
}

subscribe("fakeEvent", 
    function(ev, payload) { // <-- anonymous function!
        println (ev.name + " fired by " + ev.source.name);
    });

// fakeEvent was fired
var callback = events["fakeEvent"];
callback({name:"fakeEvent",
    source:{name:"fakeSource", foo: "bar"}}, {});