package com.steeplesoft.javascript;

import java.io.IOException;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/**
 * Run a script from a file
 *
 */
public class Example1
{
    public static void main( String[] args )
    {
        try {
            ScriptEngineManager manager = new ScriptEngineManager();
            ScriptEngine engine = manager.getEngineByName("js");
            String script = Util.readFile("example1.js");
            try {
                engine.eval(script);
                engine.eval("add(1,2);");
            } catch (ScriptException e) {
                e.printStackTrace();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
