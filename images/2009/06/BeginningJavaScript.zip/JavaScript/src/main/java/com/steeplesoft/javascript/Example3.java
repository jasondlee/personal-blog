/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.steeplesoft.javascript;

import java.io.IOException;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

/**
 *
 * @author jasonlee
 */
public class Example3 {
    public static void main( String[] args )
    {
        try {
            ScriptEngineManager manager = new ScriptEngineManager();
            ScriptEngine engine = manager.getEngineByName("js");
            String script = Util.readFile("example1.js");
            try {
                engine.eval(script);
                Invocable inv = (Invocable) engine;

                // invoke the global function named "hello"
                inv.invokeFunction("add", new Object[]{Integer.valueOf(12), Integer.valueOf(24)});

            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}