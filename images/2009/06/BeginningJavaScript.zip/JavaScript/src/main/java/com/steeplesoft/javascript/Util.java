/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.steeplesoft.javascript;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

/**
 *
 * @author jasonlee
 */
public class Util {
    public static String readFile(String filename) throws IOException {
        StringBuilder builder = new StringBuilder();
        BufferedReader in = null;
        try {
            URL url = Thread.currentThread().getContextClassLoader().getResource(filename);
            in = new BufferedReader(new InputStreamReader(new BufferedInputStream(url.openStream())));
            String str;
            while ((str = in.readLine()) != null) {
                builder.append(str + "\n");
            }
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception ex) {
                    // ignore
                }
            }
        }

        return builder.toString();
    }
}
