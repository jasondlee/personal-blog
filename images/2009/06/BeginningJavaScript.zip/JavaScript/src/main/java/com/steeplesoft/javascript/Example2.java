/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.steeplesoft.javascript;

import java.io.IOException;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/**
 *
 * @author jasonlee
 */
public class Example2 {
    public static void main( String[] args )
    {
        try {
            ScriptEngineManager manager = new ScriptEngineManager();
            ScriptEngine engine = manager.getEngineByName("js");
            String script = Util.readFile("example2.js");
            try {
                engine.eval(Util.readFile("example1.js"));
                
                engine.put("param1", Integer.valueOf(100));
                engine.put("param2", Integer.valueOf(200));

                engine.eval(script);
            } catch (ScriptException e) {
                e.printStackTrace();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}