function add(oper1, oper2) {
    print (oper1 + oper2);
}