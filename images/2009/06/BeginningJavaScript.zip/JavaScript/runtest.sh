DEPS="http://yui.yahooapis.com/2.7.0/build/yahoo-dom-event/yahoo-dom-event.js http://yui.yahooapis.com/2.7.0/build/logger/logger-min.js http://yui.yahooapis.com/2.7.0/build/yuitest/yuitest-min.js"

jrunscript $DEPS $*
