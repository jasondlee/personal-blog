/**
 * 
 */
package com.iecokc.utils.woodstock;

import com.sun.data.provider.impl.CompareFilterCriteria;


/**
 * @author Jason Lee
 *
 */
public class FilterOption {
    public String key;
    public String text;
    public CompareFilterCriteria criteria;
    
    /**
     * @param key
     * @param text
     * @param criteria
     */
    public FilterOption(String key, String text, CompareFilterCriteria criteria) {
        super();
        this.key = key;
        this.text = text;
        this.criteria = criteria;
    }

    public CompareFilterCriteria getCriteria() {
        return criteria;
    }

    public String getKey() {
        return key;
    }

    public String getText() {
        return text;
    }
    
}
