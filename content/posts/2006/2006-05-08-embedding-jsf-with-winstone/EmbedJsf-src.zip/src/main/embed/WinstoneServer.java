package embed;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import winstone.Launcher;

public class WinstoneServer {
	Launcher winstone;

	public void startup() {
		Map args = new HashMap();
		try {
			URL webdir = getClass().getResource("/WebContent");
			args.put("webroot", webdir.getPath());
			//args.put("commonLibFolder",getClass().getResource("/WebContent/WEB-INF/lib").getPath());
			System.out.println(args.toString());
			Launcher.initLogger(args);
			winstone = new Launcher(args); // spawns threads, so your application doesn't block
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void shutdown() {
		winstone.shutdown(); 
	}
	
	public static void main(String args[]) {
		WinstoneServer server = new WinstoneServer();
		server.startup();
	}
}
