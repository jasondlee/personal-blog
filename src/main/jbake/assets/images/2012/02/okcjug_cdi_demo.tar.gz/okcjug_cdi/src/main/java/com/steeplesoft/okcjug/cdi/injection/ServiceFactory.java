package com.steeplesoft.okcjug.cdi.injection;

import java.util.logging.Logger;
import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

public class ServiceFactory {
    @Produces
    public AnotherService getAnotherService() {
        return new AnotherService() {
            public String someBusinessMethod() {
                return "Here's the result of AnotherService";
            }

            public void shutdown() {
                System.out.println("Shutting down AnotherService");
            }
        };
    }

    @Produces
    public Logger createLogger(InjectionPoint injectionPoint) {
        return Logger.getLogger(injectionPoint.getMember().getDeclaringClass().getName());
    }

    public void shutdownAnotherService(@Disposes AnotherService service) {
        service.shutdown();
    }
}
