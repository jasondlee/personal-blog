package com.steeplesoft.okcjug.cdi.injection;

import com.steeplesoft.okcjug.cdi.injection.qualifiers.JDBC;
import javax.inject.Inject;
import javax.inject.Named;

@Named
public class SecondBean {
    @JDBC
    @Inject
    MyService myService;
    
    public String getSomeString() {
        return "Here is some string from MyBean";
    }
    
    public String getServiceData() {
        return myService.someServiceMethod();
    }
}
