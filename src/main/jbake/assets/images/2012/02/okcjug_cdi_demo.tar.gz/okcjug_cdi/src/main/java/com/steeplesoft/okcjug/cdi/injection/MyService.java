package com.steeplesoft.okcjug.cdi.injection;

public interface MyService {
    String someServiceMethod();
}
