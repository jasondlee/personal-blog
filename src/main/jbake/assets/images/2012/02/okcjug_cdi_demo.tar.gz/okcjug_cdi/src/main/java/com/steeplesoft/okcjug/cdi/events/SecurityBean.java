package com.steeplesoft.okcjug.cdi.events;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.enterprise.event.Event;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

@Model
public class SecurityBean {

    @Inject
    private Event<UserLoggedIn> userLoggedInEvent;
    @Inject
    private Event<LoginFailure> loginFailedEvent;
    
    @Inject
    Logger logger;
    
    private String userName;
    private String password;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String login() {
        if ("admin".equals(userName) && ("admin!".equals(password))) {
            userLoggedInEvent.fire(new UserLoggedIn(userName));
            
            return "/index?faces-redirect=true";
        } else {
            loginFailedEvent.fire(new LoginFailure());

            return "";
        }
    }

    public void recordUserLogin(@Observes UserLoggedIn uli) {
        logger.log(Level.INFO, "The user ''{0}'' has logged in.", uli.getUserName());
    }

    public void loginFailure(@Observes LoginFailure lif) {
        logger.info("A login failure occured.");
    }
}
