package com.steeplesoft.okcjug.cdi;

import com.steeplesoft.okcjug.cdi.injection.MyService;
import com.steeplesoft.okcjug.cdi.injection.qualifiers.File;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import org.jboss.weld.environment.se.Weld;
import org.jboss.weld.environment.se.WeldContainer;
import org.jboss.weld.environment.se.events.ContainerInitialized;

public class Main {
    @Inject @File
    MyService myService;
    public static void main(String... args) {
        WeldContainer weld = new Weld().initialize();
    }
    
    public void saySomething(@Observes ContainerInitialized event) {
        System.out.println(myService.someServiceMethod());
    }
}
