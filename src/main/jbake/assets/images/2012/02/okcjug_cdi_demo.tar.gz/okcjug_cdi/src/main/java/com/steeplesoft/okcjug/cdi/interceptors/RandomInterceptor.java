package com.steeplesoft.okcjug.cdi.interceptors;

import java.util.Random;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

@Unreliable
@Interceptor
public class RandomInterceptor {
    @Inject
    Logger logger;
    
    @AroundInvoke
    public Object capriciouslyReject(InvocationContext ctx) throws Exception {
        Random r = new Random();
        if (r.nextInt(2) == 1) {
            return ctx.proceed();
        } else {
            logger.info("Rejecting for no good reason!");
            return null;
        }
    }
}
