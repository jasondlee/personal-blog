package com.steeplesoft.okcjug.cdi.events;

public class LoginFailure  {
}
