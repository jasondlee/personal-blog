package com.steeplesoft.okcjug.cdi.injection;

import com.steeplesoft.okcjug.cdi.injection.qualifiers.JDBC;

@JDBC
public class JdbcService implements MyService {

    public String someServiceMethod() {
        return "Data retrieved via JDBC.";
    }
    
}
