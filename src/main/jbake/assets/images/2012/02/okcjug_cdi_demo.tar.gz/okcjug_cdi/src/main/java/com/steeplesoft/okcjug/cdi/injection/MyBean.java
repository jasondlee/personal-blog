package com.steeplesoft.okcjug.cdi.injection;

import com.steeplesoft.okcjug.cdi.interceptors.Unreliable;
import com.steeplesoft.okcjug.cdi.injection.qualifiers.File;
import com.steeplesoft.okcjug.cdi.injection.qualifiers.JDBC;
import java.util.logging.Logger;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named
@RequestScoped
@Unreliable
public class MyBean {
    @File
    @Inject
    MyService myService;
    
    @JDBC
    @Inject
    MyService myService2;
    
    @Inject
    AnotherService anotherService;
    
    @Inject
    Logger logger;
    
    public String getSomeString() {
        return "Here is some string from MyBean";
    }
    
    public String getServiceData() {
        logger.info("Calling myService");
        return myService.someServiceMethod();
    }
    
    public String getServiceData2() {
        return myService2.someServiceMethod();
    }
    
    public String getDataFromAnotherService() {
        return anotherService.someBusinessMethod();
    }
    
}
