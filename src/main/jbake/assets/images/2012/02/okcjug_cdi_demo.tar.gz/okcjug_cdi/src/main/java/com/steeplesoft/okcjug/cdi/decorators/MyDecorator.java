package com.steeplesoft.okcjug.cdi.decorators;

import com.steeplesoft.okcjug.cdi.injection.MyService;
import javax.decorator.Decorator;
import javax.decorator.Delegate;
import javax.enterprise.inject.Any;
import javax.inject.Inject;

@Decorator
public class MyDecorator implements MyService {
    @Inject @Delegate @Any MyService myService;

    public String someServiceMethod() {
        return myService.someServiceMethod().toLowerCase();
    }
    
}
