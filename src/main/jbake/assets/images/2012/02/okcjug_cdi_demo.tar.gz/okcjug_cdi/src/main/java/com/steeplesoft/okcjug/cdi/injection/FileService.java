package com.steeplesoft.okcjug.cdi.injection;

import com.steeplesoft.okcjug.cdi.injection.qualifiers.File;

@File
public class FileService implements MyService {
    public String someServiceMethod() {
        return "Data retrieved from a file";
    }
}
