package com.steeplesoft.okcjug.cdi.injection;

public interface AnotherService {
    String someBusinessMethod();
    void shutdown();
}
