package com.steeplesoft.okcjug.cdi.events;

public class UserLoggedIn {
    String userName;
    public UserLoggedIn(String name) {
        this.userName = name;
    }

    public String getUserName() {
        return userName;
    }
}
