/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.glassfish.admin.rest.restexperiment.model;

import java.util.Date;

/**
 *
 * @author jdlee
 */
//@XmlRootElement
public class Cluster {
    private String name;
    private String configRef;
    private boolean gmsEnabled;
    private String broadcast = "udpmulticast";
    private String gmsBindInterfaceAddress;
    private String gmsMulticastAddress;
    private int gmsMulticastPort;
    private Date modified = new Date();
    
    public Cluster() {
        
    }
    
    public Cluster(String name) {
        this.name = name;
    }

    public String getBroadcast() {
        return broadcast;
    }

    public void setBroadcast(String broadcast) {
        this.broadcast = broadcast;
    }

    public String getConfigRef() {
        return configRef;
    }

    public void setConfigRef(String configRef) {
        this.configRef = configRef;
    }

    public String getGmsBindInterfaceAddress() {
        return gmsBindInterfaceAddress;
    }

    public void setGmsBindInterfaceAddress(String gmsBindInterfaceAddress) {
        this.gmsBindInterfaceAddress = gmsBindInterfaceAddress;
    }

    public boolean isGmsEnabled() {
        return gmsEnabled;
    }

    public void setGmsEnabled(boolean gmsEnabled) {
        this.gmsEnabled = gmsEnabled;
    }

    public String getGmsMulticastAddress() {
        return gmsMulticastAddress;
    }

    public void setGmsMulticastAddress(String gmsMulticastAddress) {
        this.gmsMulticastAddress = gmsMulticastAddress;
    }

    public int getGmsMulticastPort() {
        return gmsMulticastPort;
    }

    public void setGmsMulticastPort(int gmsMulticastPort) {
        this.gmsMulticastPort = gmsMulticastPort;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }

    @Override
    public String toString() {
        return "Cluster{" +
                "name='" + name + '\'' +
                ", configRef='" + configRef + '\'' +
                ", gmsEnabled=" + gmsEnabled +
                ", broadcast='" + broadcast + '\'' +
                ", gmsBindInterfaceAddress='" + gmsBindInterfaceAddress + '\'' +
                ", gmsMulticastAddress='" + gmsMulticastAddress + '\'' +
                ", gmsMulticastPort=" + gmsMulticastPort +
                ", modified=" + modified +
                '}';
    }
}
