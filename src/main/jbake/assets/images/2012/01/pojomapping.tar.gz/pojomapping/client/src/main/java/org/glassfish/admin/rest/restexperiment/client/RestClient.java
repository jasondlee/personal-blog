package org.glassfish.admin.rest.restexperiment.client;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.glassfish.admin.rest.restexperiment.model.Cluster;

import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author jdlee
 */
public class RestClient {
    protected Client client;
    protected ObjectMapper mapper = new ObjectMapper();
    protected WebResource webResource;

    public RestClient() {
        ClientConfig clientConfig = new DefaultClientConfig();
        clientConfig.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);
        client = Client.create(clientConfig);
        webResource = client.resource("http://localhost:8080/rest-service");
    }

    public Cluster getCluster(String name) {
        return webResource
                .path("cluster")
                .path(name)
                .accept(MediaType.APPLICATION_JSON)
                .get(Cluster.class);
    }
    
    public ClientResponse createCluster (Cluster cluster) {
        return webResource.path("cluster")
                .type(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .post(ClientResponse.class, cluster);
    }
    
    public Cluster saveCluster(Cluster cluster) {
        ClientResponse cr = webResource.path("cluster")
                .path(cluster.getName())
                .type(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .post(ClientResponse.class, cluster);
        return cr.getEntity(Cluster.class);
    }

    public ClientResponse deleteCluster(Cluster cluster) {
        return webResource.path("cluster")
                .path(cluster.getName())
                .type(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .delete(ClientResponse.class);
    }

    public Map<String, Cluster> getClusters() {
        try {
            String json = webResource
                    .path("cluster")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(String.class);
            return mapper.readValue(json, new TypeReference<Map<String, Cluster>>() {});
        } catch (IOException e) {
        }

        return new HashMap<String, Cluster>();
    }

    public void run() {
        Cluster cluster = getCluster("c1");
        assert (cluster.getName().equals("c1"));

        Map<String, Cluster> clusters = getClusters();
        System.out.println("Number of clusters: " + clusters.size());
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
        }

        cluster.setGmsMulticastPort(1234);
        saveCluster(cluster);

        clusters = getClusters();
        System.out.println("Original time: " + cluster.getModified());
        System.out.println("New time:      " + clusters.get("c1").getModified());

        Cluster newCluster = new Cluster("newCluster");
        ClientResponse cr = createCluster(newCluster);
        int status = cr.getStatus();
        if ((status >= 200) && (status <= 299)) {
            System.out.println("Cluster created.");
        } else {
            System.out.println("Cluster creation failed: " + cr.getEntity(String.class));
        }

        System.out.println("List of clusters after create: " + getClusters());

        deleteCluster(newCluster);
        System.out.println("List of clusters after delete: " + getClusters());
    }

    public static void main(String... args) throws IOException {
        RestClient rc = new RestClient();
        rc.run();
    }
}
