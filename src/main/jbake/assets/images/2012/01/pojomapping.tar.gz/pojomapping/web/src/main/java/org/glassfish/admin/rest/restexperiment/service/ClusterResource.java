/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.glassfish.admin.rest.restexperiment.service;

import org.glassfish.admin.rest.restexperiment.model.Cluster;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author jdlee
 */
@Path("/cluster")
public class ClusterResource {
    private static Map<String, Cluster> clusters = new HashMap<String, Cluster>();

    public ClusterResource() {
        clusters.put("c1", new Cluster("c1"));
        clusters.put("c2", new Cluster("c2"));
    }

    @GET
    public Map<String, Cluster> getClusters() {
        return clusters;
    }

    @POST
    public Response addCluster(Cluster newCluster) {
        Response response;
        if (clusters.containsKey(newCluster.getName())) {
            response = Response.status(Response.Status.BAD_REQUEST)
                    .entity("That cluster already exists")
                    .build();
        } else {
            clusters.put(newCluster.getName(), newCluster);
            response = Response.ok().build();
        }
        return response;
    }

    @GET
    @Path("{name}")
    public Cluster getCluster(@PathParam("name") String name) {
        return clusters.get(name);
    }

    @POST
    @Path("{name}")
    public Response updateCluster(Cluster c) {
        c.setModified(new Date());
        clusters.put(c.getName(), c);
        Response response = Response.ok(c).build();
        return response;
    }

    @DELETE
    @Path("{name}")
    public Response deleteCluster(@PathParam("name") String name) {
        clusters.remove(name);
        return Response.ok().build();
    }
}
