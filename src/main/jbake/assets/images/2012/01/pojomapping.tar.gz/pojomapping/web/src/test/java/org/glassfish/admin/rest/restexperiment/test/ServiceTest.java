/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.glassfish.admin.rest.restexperiment.test;

import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.test.framework.JerseyTest;
import com.sun.jersey.test.framework.WebAppDescriptor;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.glassfish.admin.rest.restexperiment.model.Cluster;
import org.junit.Assert;
import org.junit.Test;

/**
 *
 * @author jdlee
 */
public class ServiceTest extends JerseyTest {

    public ServiceTest() {
        super(new WebAppDescriptor.Builder("org.glassfish.admin.rest.restexperiment.model,org.glassfish.admin.rest.restexperiment.service")
                .servletClass(com.sun.jersey.spi.container.servlet.ServletContainer.class)
                .contextPath("/service")
                .servletPath("/servlet")
                .initParam("com.sun.jersey.api.json.POJOMappingFeature", "true").build());
    }
    ObjectMapper mapper = new ObjectMapper();

    @Test
    public void testWithClient() {
        WebResource resource = resource();
        try {
            ClientResponse c = resource.path("cluster").path("c1").accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
            System.out.println(c.getStatus());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void clusterList() {
        try {
            Map<String, Cluster> map = mapper.readValue("{\"c1\":{\"name\":\"c1\",\"configRef\":null,\"gmsEnabled\":false,\"broadcast\":\"udpmulticast\",\"gmsBindInterfaceAddress\":null,\"gmsMulticastAddress\":null,\"gmsMulticastPort\":0},\"c2\":{\"name\":\"c2\",\"configRef\":null,\"gmsEnabled\":false,\"broadcast\":\"udpmulticast\",\"gmsBindInterfaceAddress\":null,\"gmsMulticastAddress\":null,\"gmsMulticastPort\":0}}",
                    new TypeReference<Map<String, Cluster>>() {
                    });
            Assert.assertEquals(2, map.size());
        } catch (Exception ex) {
            Logger.getLogger(ServiceTest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Test
    public void clusterEndpoint() {
        try {
            Cluster c = mapper.readValue("{\"name\":\"c1\",\"configRef\":null,\"gmsEnabled\":false,\"broadcast\":\"udpmulticast\",\"gmsBindInterfaceAddress\":null,\"gmsMulticastAddress\":null,\"gmsMulticastPort\":0}",
                    Cluster.class);
            Assert.assertEquals("c1", c.getName());
        } catch (Exception ex) {
            Logger.getLogger(ServiceTest.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
