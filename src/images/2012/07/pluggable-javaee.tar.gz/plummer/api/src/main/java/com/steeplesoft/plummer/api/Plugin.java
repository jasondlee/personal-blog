package com.steeplesoft.plummer.api;

/**
 *
 * @author jasonlee
 */
public interface Plugin {
    int getPriority();
}
