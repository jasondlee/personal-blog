#!/bin/bash

source ~/.bashrc

CLEAN=$1

#for APP in `asadmin list-applications | grep osgi | cut -f 1 -d " " ` ; do asadmin undeploy $APP ; done
#mvn -Dmaven.test.skip=true -f api/pom.xml $CLEAN install && \
#   mvn -Dmaven.test.skip=true -f examples/pom.xml $CLEAN install && \
#	mvn -Dmaven.test.skip=true -f kernel/pom.xml $CLEAN install && \
mvn -Dmaven.test.skip=true $CLEAN install && \
    #asadmin deploy --force=true --type=osgi api/target/plummer-api-1.0-SNAPSHOT.jar && \
    cp examples/plummer-sample*/target/plummer-sample*-1.0-SNAPSHOT.jar ~/.plugins/ && \
    #asadmin deploy --force=true --type=osgi kernel/target/plummer-kernel-1.0-SNAPSHOT.jar && \
    #asadmin deploy --force=true --type=osgi examples/plummer-example-data/target/plummer-example-data-1.0-SNAPSHOT.jar && \
    #asadmin deploy --force=true --type=osgi examples/plummer-sample1/target/plummer-sample1-1.0-SNAPSHOT.jar && \
    asadmin deploy --force=true examples/webapp/target/example-webapp-1.0-SNAPSHOT/
    #asadmin deploy --force=true --type=osgi examples/webapp/target/example-webapp-1.0-SNAPSHOT.war
